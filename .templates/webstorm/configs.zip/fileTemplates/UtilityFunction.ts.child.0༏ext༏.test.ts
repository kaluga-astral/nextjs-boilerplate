import { describe, it } from 'vitest';

import { $Name } from './$Name';

describe('$Name', () => {
  describe('', () => {
    it('', () => {
      const result = $Name();
      
      expect(result).toBe();
    });
  })
});
