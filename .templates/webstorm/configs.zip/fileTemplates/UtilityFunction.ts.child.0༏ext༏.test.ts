import { describe, it } from 'vitest';

import { $Name } from './$Name';

describe('$Name', () => {
  it('', () => {});
});
