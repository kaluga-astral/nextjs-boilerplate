import { describe, it } from 'vitest';

import { $Name } from './$Name';

describe('$Name', () => {
  describe('', () => {
    it('', () => {});
  })
});
