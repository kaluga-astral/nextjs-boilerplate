export * from './${Name}Repository';
