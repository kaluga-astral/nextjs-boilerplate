import {
  type CacheService,
  cacheService,
} from '@example/shared';

export class ${Name}Repository {
  constructor(private readonly cache: CacheService) {}
}
