import { makeAutoObservable } from 'mobx;

export class ${Name}ScreenStore {
  constructor() {
    makeAutoObservable(this, {}, { autoBind: true });
  }
}

export const create${Name}ScreenStore = () => new ${Name}ScreenStore;
