export const $Name = () => {

};

