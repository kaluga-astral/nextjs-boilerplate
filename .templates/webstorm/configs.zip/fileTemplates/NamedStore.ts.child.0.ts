import { describe, it } from 'vitest';

import { ${Name}Store } from './${Name}Store';

describe('${Name}Store', () => {
  it('', () => {});
});
