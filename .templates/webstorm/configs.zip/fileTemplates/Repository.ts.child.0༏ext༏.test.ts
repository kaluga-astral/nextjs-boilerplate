import { describe, it } from 'vitest';
import { createCacheService } from '@example/shared';

import { ${Name}Repository } from './store';

describe('${Name}Repository', () => {
  describe('', () => {
    it('', () => {
      const sut = new ${Name}Repository(createCacheService());
    });
  });
});
