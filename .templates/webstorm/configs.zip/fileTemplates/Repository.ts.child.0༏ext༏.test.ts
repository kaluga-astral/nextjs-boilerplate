import { describe, it } from 'vitest';

import { ${Name}Repository } from './${Name}';

describe('${Name}Repository', () => {
 describe('', () => {
   it('', () => {
      
  });
  });
});
