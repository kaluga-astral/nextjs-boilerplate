import { describe, it } from 'vitest';

import { ${Name}Store } from './store';

describe('${Name}Store', () => {
  it('', () => {});
});
