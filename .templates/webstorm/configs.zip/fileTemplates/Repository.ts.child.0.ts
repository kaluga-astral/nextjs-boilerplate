import { describe, it } from 'vitest';

import { createCacheService } from '@example/shared';

import { ${Name}Repository } from './${Name}Repository';

describe('${Name}Repository', () => {
  describe('', () => {
    it('', () => {
      const sut = new ${Name}Repository(createCacheService());
    });
  });
});
