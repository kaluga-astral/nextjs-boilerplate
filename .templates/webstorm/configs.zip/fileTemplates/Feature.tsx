import { useState } from 'react';
import { observer } from 'mobx-react-lite';

import { create${Name}Store } from './store';

export const $Name = observer(() => {
  const [store] = useState(create${Name}Store);
  
  return ();
});
