import { useState } from 'react';
import { observer } from 'mobx-react-lite';

import { PageLayout } from '@example/shared';

import { create${Name}ScreenStore } from './store'

export const ${Name}Screen = observer(() => {
  const [store] = useState(create${Name}ScreenStore);

  return (
    <PageLayout
      header={{ title: '' }}
      content={{ children: null, isPaddingDisabled: false }}
    />
  );
});

