export * from './${Name}Store';
