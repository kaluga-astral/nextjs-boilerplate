type ${Name}Props = {};

export const ${Name} = () => {
    return (
    
    )
};
