import { makeAutoObservable } from "mobx";

export class ${Name}Store {
  constructor() {
    makeAutoObservable(this, {}, { autoBind: true });
  }
}

export const create${Name}Store = () => new ${Name}Store();
