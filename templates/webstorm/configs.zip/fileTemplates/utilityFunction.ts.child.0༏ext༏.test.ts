import { $Name } from './$Name'

describe('$Name', () => {
    it("", () => {
      
  });
});
