import { makeAutoObservable } from "mobx";

export class $Name {
    constructor(){
        makeAutoObservable(this);
    }
}
