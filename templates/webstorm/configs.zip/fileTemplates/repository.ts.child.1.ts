import {
  type CacheService,
  cacheService,
} from '@astraledo-web/shared';

class $Name {
    constructor(private readonly cache: CacheService) {}
}
