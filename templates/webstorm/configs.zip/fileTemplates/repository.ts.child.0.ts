export namespace $Name {

}