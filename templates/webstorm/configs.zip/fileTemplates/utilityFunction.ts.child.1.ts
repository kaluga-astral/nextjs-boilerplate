export const $Name = () => {

}
