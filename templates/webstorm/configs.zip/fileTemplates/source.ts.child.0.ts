export namespace $Name  {
    
}